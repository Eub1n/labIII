public class Fila{

        private CCelula frente;
        private CCelula tras;
        
        public Fila(){
            frente = new CCelula();
            tras = frente;         
      }
      
       public boolean isEmpty(){
       return frente == tras;
      }      
       public void enfileira(Object valor){
        tras.prox= new CCelula(valor);
        tras = tras.prox;
      }
      
      public Object desinfilera(){
        Object item = null;
        if(frente != tras){
        frente = frente.prox;
        item = frente.item;
        }
        return item;
      }     
      
      public void imprimir(){
       CCelula aux = frente.prox;
       
       while(aux!= null){
       
       System.out.println(aux.item);
       aux = aux.prox; 
      
     }
    }
    
     public static void ordenar(){
     
    }
}