import java.util.Random;
public class App{

      public static void main(String args[]){
            Random gerador = new Random();
            Fila fila1 = new Fila();
            Fila fila2 = new Fila();
            for(int i = 0; i < 10; i++){
            
               fila1.enfileira(gerador.nextInt(501));
               fila2.enfileira(gerador.nextInt(501));
            }
                       
           fila1.imprimir();
           System.out.println("----");
           fila2.imprimir();
      
      }
}