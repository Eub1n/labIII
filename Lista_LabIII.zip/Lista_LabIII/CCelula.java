public class CCelula{

         public Object item;
         public CCelula prox;
         
        public CCelula(){
         this.item = null;
         this.prox = null;
    }
        
        public CCelula(CCelula cprox, Object itemvalue){
         this.item = itemvalue;
         this.prox = cprox;
   }
        public CCelula(Object itemvalue){
         this.item = itemvalue;
         this.prox = null;
  }
    
}